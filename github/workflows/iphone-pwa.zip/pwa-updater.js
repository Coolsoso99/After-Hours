/* AFTER HOURS iPhone Auto-Update Beta — V12.7.14
   Safe update architecture: check server release; stage SW update;
   activate only while idle in main menu; never during active matches.
   Requires HTTPS or localhost and a service worker-capable browser.
*/
(()=>{
 'use strict';
 const CURRENT_BUILD='20261028-ios-autoupdate-1';
 const CURRENT_VERSION='12.7.14';
 const CHECK_INTERVAL=15*60*1000;
 const applyDelayMs=4500;
 const container=document.createElement('div');
 container.id='ahUpdateBanner';
 container.hidden=true;
 container.setAttribute('role','status');
 container.setAttribute('aria-live','polite');
 container.innerHTML='<strong id="ahUpdateTitle">AFTER HOURS · UPDATE</strong><p id="ahUpdateInfo">New version available.</p><div class="ahUpdateActions"><button id="ahUpdateNow" type="button">UPDATE & RESTART</button><button id="ahUpdateLater" type="button">LATER</button></div>';
 const style=document.createElement('style');
 style.textContent=`
  #ahUpdateBanner[hidden]{display:none!important}
  #ahUpdateBanner{box-sizing:border-box;position:fixed;z-index:190;bottom:max(14px,env(safe-area-inset-bottom));left:50%;transform:translateX(-50%);width:min(92vw,420px);padding:13px 15px;border:1px solid #afbf99;background:#101813f5;color:#e5f1df;box-shadow:0 12px 40px #000c;font:13px/1.5 'Courier New',monospace;text-align:left}
  #ahUpdateTitle{font-size:13px;color:#d9e9af;letter-spacing:.08em}
  #ahUpdateInfo{margin:5px 0 10px;font-size:11px}
  .ahUpdateActions{display:flex;gap:8px;flex-wrap:wrap}
  .ahUpdateActions button{padding:9px 11px;font:700 11px 'Courier New',monospace;border:1px solid #87917a;background:#384234;color:#fff;border-radius:2px;touch-action:manipulation}
  .ahUpdateActions button:first-child{background:#bed1aa;color:#101710;border-color:#d6ecc0}
  .ahUpdateActions button:disabled{opacity:.5}
  @media(max-width:400px){#ahUpdateBanner{bottom:max(8px,env(safe-area-inset-bottom));padding:10px}}
 `;
 document.head.appendChild(style);document.body.appendChild(container);
 const $=id=>document.getElementById(id);
 const nowBtn=$('ahUpdateNow'),laterBtn=$('ahUpdateLater');
 let registration=null,waiting=null,manualStatus=null,checking=false;
 let applying=false,autoTimer=null,snoozedBuild=null,lastManifest=null;
 let updatePendingNotification=false;
 function isSafe(){
   const menu=$('mainMenu');
   if(!menu || menu.classList.contains('hidden'))return false;
   if(typeof s!=='undefined' && (s.phase==='playing'||s.phase==='warmup'||s.reporting))return false;
   if(typeof coopRole!=='undefined' && coopRole!=='solo')return false;
   const lobby=$('coopLobby');if(lobby&&!lobby.hidden)return false;
   const editor=$('editorModal');if(editor&&editor.classList.contains('open'))return false;
   return true;
 }
 function banner(title,info){$('ahUpdateTitle').textContent=title;$('ahUpdateInfo').textContent=info;container.hidden=false;}
 function status(text){if(manualStatus)manualStatus.textContent=text;}
 function cancelAuto(){if(autoTimer){clearTimeout(autoTimer);autoTimer=null;}}
 function hide(){cancelAuto();container.hidden=true;}
 function showReady(){
   if(!waiting||!navigator.serviceWorker.controller||!isSafe()||applying)return;
   if(snoozedBuild===(lastManifest?.build||'unknown'))return;
   const v=(lastManifest&&lastManifest.version)||'new';
   banner('UPDATE READY · V'+v,'New version downloaded. Tap UPDATE & RESTART when ready, or LATER to keep playing. Your saved level and upgrades remain.');
   nowBtn.hidden=false;laterBtn.hidden=false;nowBtn.disabled=false;nowBtn.textContent='UPDATE & RESTART';
   cancelAuto(); // Wait for player approval; never force a restart.
 }
 function signalWhenSafe(){
   if(waiting && isSafe())showReady();
   else if(!isSafe())hide();
 }
 function applyUpdate(){
   if(!waiting||!isSafe()||applying)return;
   applying=true;cancelAuto();
   banner('INSTALLING UPDATE','Applying the new version and restarting AFTER HOURS…');
   nowBtn.disabled=true;laterBtn.hidden=true;
   try{waiting.postMessage({type:'AFTER_HOURS_ACTIVATE_UPDATE'});}
   catch(e){applying=false;banner('UPDATE COULD NOT START','Close and reopen the Home Screen app to retry.');}
 }
 nowBtn.addEventListener('click',applyUpdate);
 laterBtn.addEventListener('click',()=>{
   snoozedBuild=lastManifest?.build||'unknown';
   hide();status('Update postponed until you reopen the app.');
 });
 function attachInstalling(w){
   if(!w)return;
   w.addEventListener('statechange',()=>{
     if(w.state==='installed' && navigator.serviceWorker.controller){
       waiting=registration?.waiting||w;
       status('Update downloaded — installs safely from the main menu.');
       signalWhenSafe();
     }
   });
 }
 function setupReg(reg){
   registration=reg;
   if(reg.waiting && navigator.serviceWorker.controller){waiting=reg.waiting;signalWhenSafe();}
   if(reg.installing)attachInstalling(reg.installing);
   reg.addEventListener('updatefound',()=>{
     if(reg.installing)attachInstalling(reg.installing);
     status('Downloading new app version…');
   });
 }
 navigator.serviceWorker?.addEventListener('controllerchange',()=>{
   if(applying){window.location.reload();}
 });
 async function checkUpdates(manual=false){
   if(checking)return;
   checking=true;
   if(manual)status('Checking for updates…');
   try{
     if(registration)await registration.update();
     const response=await fetch('./release.json?check='+Date.now(),{cache:'no-store'});
     if(!response.ok)throw Error('Server returned '+response.status);
     const data=await response.json();
     if(!data||typeof data.build!=='string')throw Error('Invalid version manifest');
     lastManifest=data;
     if(data.build===CURRENT_BUILD){
       if(manual)status('Up to date · V'+CURRENT_VERSION);
     }else{
       status('New version available · V'+(data.version||'?'));
       if(registration && !registration.waiting)await registration.update();
       if(registration?.waiting && navigator.serviceWorker.controller){waiting=registration.waiting;signalWhenSafe();}
       else if(manual)status('Downloading update. Keep AFTER HOURS open on the menu briefly.');
     }
   }catch(err){if(manual)status('Cannot check updates right now. Internet/HTTPS required.');}
   finally{checking=false;signalWhenSafe();}
 }
 function setupManual(){
   const settings=$('menuConfig');if(!settings)return;
   const row=document.createElement('div');row.className='settingRow';row.style.marginTop='12px';
   const label=document.createElement('label');label.textContent='APP UPDATES · '+CURRENT_VERSION+' · AUTO CHECK ENABLED';row.appendChild(label);
   const btn=document.createElement('button');btn.className='smallbtn';btn.type='button';btn.textContent='CHECK FOR UPDATES';
   btn.addEventListener('click',()=>checkUpdates(true));row.appendChild(btn);
   manualStatus=document.createElement('div');manualStatus.setAttribute('role','status');
   manualStatus.style.cssText='margin-top:9px;color:#c3cfb5;font:11px/1.5 Courier New,monospace';
   manualStatus.textContent='Checks automatically when opened and while online.';
   row.appendChild(manualStatus);settings.appendChild(row);
 }
 setupManual();
 if(!('serviceWorker' in navigator) || !['https:','http:'].includes(location.protocol)){
   status('Updates require an HTTPS-hosted Home Screen app.');return;
 }
 if(location.protocol!=='https:' && !['localhost','127.0.0.1'].includes(location.hostname)){
   status('Updates require HTTPS.');return;
 }
 const menu=$('mainMenu');
 if(menu)new MutationObserver(()=>signalWhenSafe()).observe(menu,{attributes:true,attributeFilter:['class']});
 document.addEventListener('visibilitychange',()=>{
   if(!document.hidden){snoozedBuild=null;checkUpdates();signalWhenSafe();}
 });
 window.addEventListener('focus',()=>{if(!document.hidden)checkUpdates();});
 window.setInterval(()=>{if(!document.hidden)checkUpdates();},CHECK_INTERVAL);
 window.addEventListener('load',async()=>{
   try{
     const reg=await navigator.serviceWorker.register('./service-worker.js',{updateViaCache:'none',scope:'./'});
     setupReg(reg);
     await checkUpdates();
   }catch(err){status('Offline updates unavailable: use an HTTPS host.');console.warn('AFTER HOURS update setup:',err);}
 });
})();
