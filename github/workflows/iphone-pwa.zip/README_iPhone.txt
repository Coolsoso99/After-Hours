AFTER HOURS V12.7.14 — iPhone Lightweight PWA
UNDER 25 MB ZIP, optimized to fit hosting/upload size limits.

This is a HOME SCREEN WEB APP, not an iPhone IPA.

Installation:
1. Extract the ZIP on your computer. Upload ALL contents together to an HTTPS host.
2. Keep index.html, assets/, icons/, service-worker.js, and manifest.webmanifest in their original relative folders.
3. On iPhone, open the website in Safari, tap Share, then Add to Home Screen.
4. Open AFTER HOURS from its Home Screen icon.

The package is now multiple small files instead of a huge single HTML file.
IMPORTANT: Upload the entire extracted folder, not only index.html, or images/sound will not work.

Included: V12.7.14 Pursuer balancing (Easy 0 / Normal 1 / Hard 2 / Nightmare 4), working multiplayer menu, no editor on launch, mobile tech tree touch-drag, all camera assets and game audio.
Media images are WebP-optimized where smaller; source gameplay and audio code has not been altered.
The service worker now precaches media in small batches for offline play after successful loading. Wait for the first visit to finish downloading before going offline. Multiplayer relay still needs Internet.
This package uses a fresh cache name. It may be helpful to remove the previous Home Screen icon and reopen the new URL in Safari after uploading.

Website limit note: The compressed ZIP is under 25MB and the largest extracted file is also under 25MB. This does not bypass any host-specific quota or upload count limit.
