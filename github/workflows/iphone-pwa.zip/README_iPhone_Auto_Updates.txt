AFTER HOURS V12.7.14 — iPhone Auto-Update Beta
===============================================

PACKAGE: Home Screen iPhone PWA. NOT a signed iOS IPA / App Store submission.

ONE-TIME INSTALL
1. Extract ALL files and folders from this ZIP.
2. Upload the *contents* to a permanent HTTPS web host (all 278 media assets included).
3. Keep the same HTTPS URL for every future release.
4. Open the URL in Safari on iPhone > Share > Add to Home Screen.
5. Launch from the Home Screen icon. Keep internet on for the initial full download.

UPDATING AFTER THIS FIRST INSTALL
1. Make your updated game version, then increment the release.json "build" and
   "version" fields. The build string must change on every published release.
2. Also change CACHE_NAME inside service-worker.js for every release so the browser
   can detect and download the new offline version.
3. Replace the existing hosted files at the SAME URL (prefer one atomic deployment).
4. The installed iPhone app checks on opening, when returning to the foreground,
   and every 15 minutes while visible. It installs the staged update on the MAIN MENU
   when you tap UPDATE & RESTART, NEVER during an active shift or multiplayer lobby.
5. You can also click Settings > CHECK FOR UPDATES.

If the site is offline, the existing version continues working once fully cached.
Releasing new assets: keep old hashed assets until the new service worker has been
published/installed; never replace asset files in place with different content.

IMPORTANT: A future version is NOT automatically published by creating this ZIP.
You must host the files and publish a new release to that same site for checks to work.
No live update server is provisioned by this ZIP.

Tech notes: service-worker.js precaches the shell and images/audio, and holds a new
update in the WAITING state. The updater shows a safe restart banner on the main menu
and sends a message to activate it. No alert or restart during gameplay.
Checks use an uncached release.json file; service worker is registered with
updateViaCache: none; install remains under 25 MB ZIP limit.

Controls from the original V12.7.14 iPhone Lite release and all existing saves
are unchanged. Existing saves are preserved when keeping the same HTTPS origin.
Multiplayer requires internet and matching game builds across devices.

DEPLOYMENT: Add server header Cache-Control: no-cache for service-worker.js,
index.html, release.json; immutable long-term caching is fine for hashed assets.
Ensure .webmanifest, .webp, .mp3 MIME types are served correctly.
